--
-- Greenplum Database database dump
--

SET statement_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = off;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET escape_string_warning = off;

SET search_path = madlibtestdata, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: empty_table; Type: TABLE; Schema: madlibtestdata; Owner: qianh1; Tablespace: 
--

CREATE TABLE empty_table (
    x double precision[],
    y double precision,
    cl text
);



--
-- Data for Name: empty_table; Type: TABLE DATA; Schema: madlibtestdata; Owner: qianh1
--

COPY empty_table (x, y, cl) FROM stdin;
\.


--
-- Greenplum Database database dump complete
--

